#!/usr/bin/env python3
"""
Invoice Generator — Create professional PDF invoices from JSON/CSV data.
Zero dependencies beyond Python stdlib. Fully customizable template.
"""
import json, csv, sys
from datetime import datetime
from pathlib import Path

HTML_TEMPLATE = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:'Helvetica Neue',Arial,sans-serif;color:#1a1a2e;max-width:800px;margin:40px auto}}
.header{{display:flex;justify-content:space-between;border-bottom:3px solid #2563eb;padding-bottom:20px;margin-bottom:30px}}
.company h1{{font-size:28px;color:#2563eb}}
.company p{{font-size:14px;color:#64748b;margin-top:4px}}
.invoice-info{{text-align:right}}
.invoice-info h2{{font-size:24px;color:#1e293b}}
.invoice-info p{{font-size:13px;color:#64748b;margin-top:4px}}
.client{{margin-bottom:30px}}
.client h3{{font-size:16px;color:#475569;margin-bottom:4px}}
.client p{{font-size:14px;color:#1e293b;line-height:1.6}}
table{{width:100%;border-collapse:collapse;margin:20px 0}}
th{{background:#2563eb;color:white;padding:12px;text-align:left;font-size:13px;text-transform:uppercase;letter-spacing:0.5px}}
td{{padding:12px;border-bottom:1px solid #e2e8f0;font-size:14px}}
.total{{text-align:right;margin-top:20px}}
.total h2{{font-size:28px;color:#2563eb}}
.footer{{margin-top:40px;padding-top:20px;border-top:2px solid #e2e8f0;font-size:12px;color:#94a3b8;text-align:center}}
</style></head><body>
<div class="header">
<div class="company"><h1>{company_name}</h1><p>{company_address}</p><p>{company_email}</p></div>
<div class="invoice-info"><h2>INVOICE</h2><p>#{invoice_number}</p><p>Date: {date}</p><p>Due: {due_date}</p></div>
</div>
<div class="client"><h3>Bill To:</h3><p>{client_name}<br>{client_address}<br>{client_email}</p></div>
<table><thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Amount</th></tr></thead><tbody>{items_html}</tbody></table>
<div class="total"><h2>Total: {currency}{total:.2f}</h2></div>
<div class="footer"><p>Thank you for your business! | Payment due within {payment_terms} days</p></div>
</body></html>"""

def generate_invoice(data, output_path=None):
    """Generate HTML invoice from dictionary data"""
    items_html = ""
    for item in data.get("items", []):
        amount = item["quantity"] * item["rate"]
        items_html += f'<tr><td>{item["description"]}</td><td>{item["quantity"]}</td><td>{data.get("currency","$")}{item["rate"]:.2f}</td><td>{data.get("currency","$")}{amount:.2f}</td></tr>'
    
    total = sum(i["quantity"] * i["rate"] for i in data.get("items", []))
    
    html = HTML_TEMPLATE.format(
        company_name=data.get("company_name", "Your Company"),
        company_address=data.get("company_address", ""),
        company_email=data.get("company_email", ""),
        invoice_number=data.get("invoice_number", "001"),
        date=data.get("date", datetime.now().strftime("%Y-%m-%d")),
        due_date=data.get("due_date", ""),
        client_name=data.get("client_name", ""),
        client_address=data.get("client_address", ""),
        client_email=data.get("client_email", ""),
        items_html=items_html,
        currency=data.get("currency", "$"),
        total=total,
        payment_terms=data.get("payment_terms", 14)
    )
    
    if not output_path:
        output_path = f"invoice_{data.get('invoice_number','001')}.html"
    
    with open(output_path, 'w') as f:
        f.write(html)
    
    print(f"✅ Invoice saved: {output_path}")
    return output_path

def from_json(json_path):
    """Load invoice data from JSON file"""
    with open(json_path) as f:
        return json.load(f)

def from_csv(csv_path):
    """Load invoice items from CSV (description,qty,rate)"""
    with open(csv_path) as f:
        reader = csv.DictReader(f)
        items = [{"description": r['description'], "quantity": int(r.get('qty',1)), "rate": float(r.get('rate',0))} for r in reader]
    return {"items": items}

# CLI
if __name__ == "__main__":
    if len(sys.argv) < 2:
        # Demo mode
        print("📄 Invoice Generator — Demo Mode\n")
        demo = {
            "company_name": "Lux in Umbra",
            "company_address": "Stuttgart, Germany",
            "company_email": "hello@luxinumbra.com",
            "invoice_number": "2026-001",
            "date": datetime.now().strftime("%Y-%m-%d"),
            "due_date": "2026-07-07",
            "client_name": "Max Mustermann GmbH",
            "client_address": "Musterstraße 1, 10115 Berlin",
            "client_email": "max@mustermann.de",
            "currency": "€",
            "payment_terms": 14,
            "items": [
                {"description": "Python Automation Consulting", "quantity": 5, "rate": 120.00},
                {"description": "SEO Tool Setup & Training", "quantity": 1, "rate": 350.00},
                {"description": "Monthly Maintenance (June)", "quantity": 1, "rate": 99.00},
            ]
        }
        generate_invoice(demo)
    else:
        data = from_json(sys.argv[1])
        generate_invoice(data)
