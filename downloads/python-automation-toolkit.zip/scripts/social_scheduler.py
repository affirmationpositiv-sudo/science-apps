#!/usr/bin/env python3
"""
Social Media Scheduler — Post to Telegram, Twitter (via free APIs), and schedule posts.
Uses Telegram Bot API (free). Extendable to other platforms.
"""
import json, time, sys, os
from datetime import datetime, timedelta
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import urlencode

class SocialScheduler:
    """Schedule and post to multiple platforms via free APIs"""
    
    def __init__(self, config_path=None):
        self.config = {}
        self.schedule_file = Path.home() / ".social_schedule.json"
        if config_path:
            with open(config_path) as f:
                self.config = json.load(f)
        self._load_schedule()
    
    def _load_schedule(self):
        if self.schedule_file.exists():
            with open(self.schedule_file) as f:
                self.schedule = json.load(f)
        else:
            self.schedule = {"posts": [], "posted": []}
    
    def _save_schedule(self):
        with open(self.schedule_file, 'w') as f:
            json.dump(self.schedule, f, indent=2)
    
    def configure_telegram(self, bot_token, chat_id):
        """Configure Telegram bot (free)"""
        self.config["telegram"] = {"bot_token": bot_token, "chat_id": chat_id}
    
    def post_to_telegram(self, text):
        """Send message via Telegram Bot API"""
        cfg = self.config.get("telegram", {})
        if not cfg:
            print("Telegram not configured. Call configure_telegram() first.")
            return False
        url = f"https://api.telegram.org/bot{cfg['bot_token']}/sendMessage"
        data = urlencode({"chat_id": cfg["chat_id"], "text": text, "parse_mode": "HTML"}).encode()
        req = Request(url, data=data)
        try:
            with urlopen(req, timeout=10) as resp:
                result = json.loads(resp.read())
            if result.get("ok"):
                print(f"✅ Posted to Telegram: {text[:50]}...")
                return True
            else:
                print(f"❌ Telegram error: {result}")
                return False
        except Exception as e:
            print(f"❌ Telegram failed: {e}")
            return False
    
    def schedule_post(self, platform, text, post_time=None, image_url=None):
        """Schedule a post for future publishing"""
        if post_time is None:
            post_time = (datetime.now() + timedelta(hours=1)).isoformat()
        post = {
            "platform": platform,
            "text": text,
            "scheduled": post_time,
            "image_url": image_url,
            "status": "scheduled"
        }
        self.schedule["posts"].append(post)
        self._save_schedule()
        print(f"📅 Scheduled [{platform}] for {post_time}: {text[:40]}...")
    
    def process_schedule(self):
        """Publish all due posts"""
        now = datetime.now()
        due = [p for p in self.schedule["posts"] if p["status"] == "scheduled" and datetime.fromisoformat(p["scheduled"]) <= now]
        
        for post in due:
            if post["platform"] == "telegram" and "telegram" in self.config:
                self.post_to_telegram(post["text"])
                post["status"] = "posted"
                post["posted_at"] = now.isoformat()
                self.schedule["posted"].append(post)
        
        self.schedule["posts"] = [p for p in self.schedule["posts"] if p["status"] != "posted"]
        self._save_schedule()
        return len(due)

# CLI
if __name__ == "__main__":
    sched = SocialScheduler()
    
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        print("📱 Social Scheduler — Demo\n")
        sched.schedule_post("telegram", "🚀 Just launched: Python Automation Toolkit — 5 scripts that replace $200/mo SaaS tools!", 
                           post_time=datetime.now().isoformat())
        sched.schedule_post("telegram", "💡 Hot take: Most 'AI automation' is overpriced. Here's how to do it with 50 lines of Python.", 
                           post_time=(datetime.now() + timedelta(hours=4)).isoformat())
        print(f"\nSaved to: {sched.schedule_file}")
    else:
        # Process any due posts
        posted = sched.process_schedule()
        print(f"Published {posted} scheduled posts")
        pending = len([p for p in sched.schedule["posts"] if p["status"] == "scheduled"])
        print(f"Pending: {pending}")
