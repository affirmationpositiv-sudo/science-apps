#!/usr/bin/env python3
"""
SEO Rank Tracker — Track keyword positions via DuckDuckGo/Google free scrapers.
No API keys required. Outputs CSV report with position changes.
"""
import csv, json, time, sys
from datetime import datetime
from urllib.request import Request, urlopen
from urllib.parse import quote_plus
from pathlib import Path

class SEORankTracker:
    """Free SEO position tracker — no API key needed"""
    
    def __init__(self, output_dir="reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(exist_ok=True)
        self.results = []
    
    def search(self, keyword, num_results=20):
        """Search via DuckDuckGo HTML (no API key)"""
        url = f"https://html.duckduckgo.com/html/?q={quote_plus(keyword)}"
        req = Request(url, headers={"User-Agent": "Mozilla/5.0"})
        try:
            with urlopen(req, timeout=10) as resp:
                html = resp.read().decode()
            # Extract result links
            import re
            links = re.findall(r'class="result__url"[^>]*>(.*?)<', html)
            return [l.strip() for l in links[:num_results]]
        except Exception as e:
            print(f"  Search error: {e}")
            return []
    
    def check_position(self, keyword, domain):
        """Check where a domain ranks for a keyword"""
        results = self.search(keyword)
        for i, url in enumerate(results):
            if domain.lower() in url.lower():
                return i + 1  # 1-indexed position
        return None  # Not in results
    
    def track_keywords(self, keywords, domain, label=""):
        """Track multiple keywords for a domain"""
        timestamp = datetime.now().isoformat()
        for kw in keywords:
            pos = self.check_position(kw, domain)
            status = f"#{pos}" if pos else "Not found"
            print(f"  {kw:30s} → {status}")
            self.results.append({
                "timestamp": timestamp,
                "keyword": kw,
                "domain": domain,
                "position": pos,
                "label": label
            })
    
    def save_report(self, filename=None):
        """Save results as CSV report"""
        if not self.results:
            print("No results to save.")
            return None
        if not filename:
            filename = f"seo_report_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
        path = self.output_dir / filename
        with open(path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=["timestamp", "keyword", "domain", "position", "label"])
            writer.writeheader()
            writer.writerows(self.results)
        print(f"\nReport saved: {path}")
        return path

if __name__ == "__main__":
    tracker = SEORankTracker()
    if len(sys.argv) > 1:
        domain = sys.argv[1]
        keywords = sys.argv[2:] if len(sys.argv) > 2 else ["automation tools", "python script"]
    else:
        domain = "github.com"
        keywords = ["python automation", "free seo tools"]
    
    print(f"Tracking {len(keywords)} keywords for {domain}...")
    tracker.track_keywords(keywords, domain)
    tracker.save_report()
