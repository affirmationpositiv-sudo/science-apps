#!/usr/bin/env python3
"""
Website Uptime Monitor — Check site availability, alert via Telegram on downtime.
Runs as daemon or one-shot check. Zero API keys required.
"""
import time, json, sys
from datetime import datetime
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError

class UptimeMonitor:
    """Monitor websites and alert on downtime via Telegram (free)"""
    
    def __init__(self, sites_file=None, telegram_config=None):
        self.sites_file = Path(sites_file) if sites_file else Path.home() / ".monitor_sites.json"
        self.telegram = telegram_config or {}
        self.log_file = Path.home() / ".uptime_log.jsonl"
        self._load_sites()
    
    def _load_sites(self):
        if self.sites_file.exists():
            with open(self.sites_file) as f:
                self.sites = json.load(f)
        else:
            self.sites = []
    
    def add_site(self, url, name=None):
        """Add a site to monitor"""
        self.sites.append({
            "url": url,
            "name": name or url,
            "added": datetime.now().isoformat(),
            "status": "unknown",
            "last_check": None,
            "consecutive_failures": 0,
            "total_checks": 0,
            "total_failures": 0,
            "uptime_pct": 100.0
        })
        self._save()
    
    def check_site(self, site):
        """Check single site, return (ok, response_time_ms, status_code)"""
        start = time.time()
        try:
            req = Request(site["url"], headers={"User-Agent": "UptimeMonitor/1.0"})
            with urlopen(req, timeout=15) as resp:
                rt = (time.time() - start) * 1000
                return True, rt, resp.status
        except Exception as e:
            rt = (time.time() - start) * 1000
            return False, rt, str(e)
    
    def check_all(self):
        """Check all sites once"""
        alerts = []
        for site in self.sites:
            ok, rt, detail = self.check_site(site)
            site["last_check"] = datetime.now().isoformat()
            site["total_checks"] += 1
            
            if ok:
                site["status"] = "up"
                site["consecutive_failures"] = 0
                emoji = "🟢"
            else:
                site["status"] = "down"
                site["consecutive_failures"] += 1
                site["total_failures"] += 1
                emoji = "🔴"
                alerts.append(site)
            
            site["uptime_pct"] = round((1 - site["total_failures"] / max(site["total_checks"], 1)) * 100, 2)
            
            # Log
            with open(self.log_file, 'a') as f:
                f.write(json.dumps({"time": site["last_check"], "site": site["name"], 
                                   "ok": ok, "response_ms": round(rt), "detail": str(detail)}) + "\n")
            
            print(f"  {emoji} {site['name']:30s} {int(rt)}ms — {site['uptime_pct']}% uptime")
        
        self._save()
        return alerts
    
    def send_alert(self, site):
        """Send Telegram alert for down site"""
        if not self.telegram:
            return
        text = f"🔴 DOWN: {site['name']}\n{site['url']}\nFailures: {site['consecutive_failures']}\nTime: {datetime.now().strftime('%H:%M:%S')}"
        from urllib.parse import urlencode
        url = f"https://api.telegram.org/bot{self.telegram['bot_token']}/sendMessage"
        data = urlencode({"chat_id": self.telegram["chat_id"], "text": text}).encode()
        try:
            urlopen(Request(url, data=data), timeout=10)
        except:
            pass
    
    def _save(self):
        with open(self.sites_file, 'w') as f:
            json.dump(self.sites, f, indent=2)
    
    def run_daemon(self, interval_seconds=300):
        """Run continuously, checking every N seconds"""
        print(f"🔍 Uptime Monitor started — checking {len(self.sites)} sites every {interval_seconds}s")
        try:
            while True:
                print(f"\n--- Check {datetime.now().strftime('%H:%M:%S')} ---")
                alerts = self.check_all()
                for site in alerts:
                    self.send_alert(site)
                if alerts:
                    print(f"⚠️  {len(alerts)} site(s) DOWN — alerts sent!")
                time.sleep(interval_seconds)
        except KeyboardInterrupt:
            print("\nMonitor stopped.")

# CLI
if __name__ == "__main__":
    monitor = UptimeMonitor()
    if len(sys.argv) > 1:
        if sys.argv[1] == "add":
            monitor.add_site(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
        elif sys.argv[1] == "daemon":
            monitor.run_daemon()
        else:
            monitor.add_site(sys.argv[1])
            monitor.check_all()
    else:
        # Demo: add some sites and check
        if not monitor.sites:
            monitor.add_site("https://github.com", "GitHub")
            monitor.add_site("https://google.com", "Google")
            monitor.add_site("https://httpstat.us/200", "Test OK")
        monitor.check_all()
        print(f"\n💡 Run with 'daemon' for continuous monitoring")
