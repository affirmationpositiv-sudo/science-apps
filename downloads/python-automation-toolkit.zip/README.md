# 🐍 Python Automation Toolkit — 5 Zero-Cost Workflows

**Replace $200+/month SaaS tools with 5 Python scripts that run forever for free.**

---

## What You Get

| # | Script | Replaces | Value |
|---|--------|----------|-------|
| 1 | **SEO Rank Tracker** | Ahrefs/Semrush ($99/mo) | Track keyword positions via free search APIs |
| 2 | **Invoice Generator** | FreshBooks ($17/mo) | Professional PDF invoices from JSON/CSV |
| 3 | **Social Media Scheduler** | Buffer ($6/mo) | Schedule posts via free Telegram Bot API |
| 4 | **Website Uptime Monitor** | Pingdom ($10/mo) | 24/7 monitoring with Telegram alerts |
| 5 | **Data Scraper + Reporter** | Import.io ($299/mo) | Competitor prices → CSV + HTML reports |

**Total SaaS cost replaced: $431/month → $0 forever.**

---

## Quick Start

```bash
# 1. SEO Rank Tracker
python3 scripts/seo_rank_tracker.py yourdomain.com keyword1 keyword2

# 2. Invoice Generator (demo mode)
python3 scripts/invoice_generator.py
# Or with real data:
python3 scripts/invoice_generator.py my_invoice_data.json

# 3. Social Media Scheduler
python3 scripts/social_scheduler.py demo

# 4. Uptime Monitor
python3 scripts/uptime_monitor.py
# Continuous mode:
python3 scripts/uptime_monitor.py daemon

# 5. Data Scraper
python3 scripts/data_scraper.py "your product" competitor1 competitor2
```

---

## Requirements

- **Python 3.8+** (nothing else — zero dependencies)
- For Telegram features: free bot token from [@BotFather](https://t.me/BotFather)
- macOS / Linux / Windows

---

## What Makes This Different

- **Zero recurring costs** — no APIs, no subscriptions, no usage limits
- **Pure Python stdlib** — no `pip install` needed
- **Extensible** — every script is documented and modular
- **Production-ready** — error handling, logging, CSV exports
- **Works offline** — no cloud dependencies

---

## Who Is This For?

- Freelancers sick of SaaS billing
- Small business owners automating workflows
- Developers building internal tools
- Anyone who wants to stop paying monthly for simple scripts

---

## Support

Each script includes `--help` and demo modes. Run any script without arguments to see it in action.

---

**Price: $29** (one-time, lifetime updates)

© 2026 Lux in Umbra
