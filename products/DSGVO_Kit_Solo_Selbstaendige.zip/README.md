# DSGVO-Kit für Solo-Selbstständige

## Was du bekommst

**3 fertige HTML-Vorlagen** — kopieren, Platzhalter ersetzen, fertig:

1. **Datenschutzerklärung** — DSGVO-konform mit allen Artikeln (Art. 6, 15-20, 28)
2. **Impressum** — §5 TMG + §55 RStV konform
3. **AGB** — Standard-AGB für Dienstleister/Freelancer

## Für wen?

- Freelancer und Solo-Selbstständige in Deutschland
- Kleine Webseiten-Betreiber
- Blogger und Content Creator
- Jeder, der keine €500 für einen Anwalt ausgeben will

## So funktioniert's

1. HTML-Datei öffnen
2. Platzhalter `{FIRMA}`, `{EMAIL}` etc. ersetzen
3. Auf deine Website hochladen
4. Fertig — in 10 Minuten

## Was du sparst

- Anwalt: €200-500 pro Dokument
- Generator-Tools: €10-30/Monat Abo
- **Dieses Kit: €29 EINMALIG, alle 3 Dokumente**

## ⚠️ Wichtiger Hinweis

Dieses Kit ersetzt keine Rechtsberatung. Es bietet eine solide Basis, die du an deine spezifische Situation anpassen musst. Bei komplexen Geschäftsmodellen konsultiere einen Anwalt.

---
**Lux in Umbra © 2026** — Premium digitale Produkte
