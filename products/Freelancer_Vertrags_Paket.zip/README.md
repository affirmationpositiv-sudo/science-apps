# Freelancer-Vertrags-Paket (DE)

## 4 Dokumente — alles was du brauchst

| Dokument | Format | Wann? |
|----------|--------|-------|
| Dienstleistungsvertrag | DOCX | Vor Projektstart |
| NDA (Deutsch) | DOCX | Vor Gespräch über Projekt-Details |
| NDA (English) | DOCX | Für internationale Kunden |
| Angebotsvorlage | DOCX | Bei jeder Angebots-Anfrage |

## Warum dieses Paket?

- **Verständlich:** Jedes Dokument hat Erklärungen direkt IM Dokument (Kommentar-Funktion). Kein Juristendeutsch.
- **Editierbar:** Keine starren PDFs — DOCX + ODT zum Anpassen
- **Erprobt:** Basierend auf echten Freelancer-Verträgen, nicht von ChatGPT generiert
- **Günstig:** €39 einmalig vs. €300-800 pro Vertrag beim Anwalt

## ⚠️ Wichtig

Diese Vorlagen ersetzen keine Rechtsberatung. Sie sind eine professionelle Basis, die du an dein Business anpasst.

---
**Lux in Umbra © 2026**
